# GameMerchandise

## setup

To setup everything you need, please run the import.sql .

In this import 2 tables will be added. Gamemerch contains all the information about the games, and userdata contains data for the users.

Passwords are encrypted, so unless you got a tool to decrypt them, there's no way of recovering them.

## Start

To run the project, setup something like apache to run php files.

It's also required to install some kind of database manager with or compatible with MySQL.

Edit connect.php to your server and credentials, and you're good to go!

## login info

Username: sanderei

Password: sterkwachtwoord



Online available at projects.nickmous.com
